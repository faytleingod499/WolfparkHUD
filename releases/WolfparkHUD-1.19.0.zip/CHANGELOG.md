## 1.19.0
- **Fold the panel:** click the `::` handle (without dragging) and the panel folds into a small wolf-face button in the
  same spot. Drag the button to move it, click it to open the panel again. It remembers if it was folded.
- **Chalk menu: Clear.** Admins get a small **Clear** button next to the canvas numbers that wipes the picked canvas
  for everybody (second click to confirm). Needs the server's ClearChalk plugin.
- **Message colour:** a small round swatch next to the **?** button opens a thin hue slider for the colour of server
  messages in your own chat. The default stays the server's sky blue, **Reset** brings it back. Only new messages change.

## 1.18.1
- Admins: **Ban** in the player list now opens a box for the reason (optional). The Ban button in the box, or Enter, sends the
  ban with the reason, which is written to bans.txt and shown in the Bans list. Click Ban again to close the box. The reason
  is saved with any server, the Bans list needs the updated server.

## 1.18.0
- Admins get a **Bans** button at the top of the admin panel (shield) that shows the server's ban list from bans.txt,
  newest first. Each ban has an **Unban** button (a second click confirms) and a **Reason** button to add or change the
  reason shown under the name. Needs the updated server (it adds the hidden !banlist and !banreason commands); on an
  older server the list says it got no answer.

## 1.17.2
- The HUD's hello to the server (used for buffs) is only sent to servers that understand it, once on arrival and then every
  5 minutes instead of every 30 seconds. It no longer fills the server console or gets "Command not found" from older servers.

## 1.17.1
- Hover over an item in the Buy menu to read what it does (buffs, meteor, rain cloud...). The server supplies the text,
  so it needs the updated Feed plugin; with an older one the Buy menu looks as before.

## 1.17.0
- Buffs in the Buy menu: the server can now sell the game's own drink effects (Speed Drink, Speed Burst, Lucky Catch, Big
  Catch, Deluxe Catch with extra XP, Bouncy, Mega Bounce). They work exactly like the drinks, for the same time, but need
  no item, and they are never saved. The HUD tells the server it can apply them; players on an older HUD are not sold
  buffs. Needs the updated Feed plugin on the server.

## 1.16.5
- Admin panel: the list now starts with "Players online: N", the total number of players on the server (you included).

## 1.16.4
- Catch coins: every fish you catch earns wolf coins on Wolf Park, by quality: Normal 1, Shining 2, Glistening 3,
  Opulent 4, Radiant 5, Alpha 6. The HUD tells the server what quality you caught; the server checks that it saw you
  land that fish and pays each catch once. Needs a server with catch coins turned on.

## 1.16.3
- The command list is in alphabetical order.
- Clicking a command sends it to the server right away, no typing. Commands that need more (a player, an amount, a
  name...) open a small box under them with a hint of what to type; press Enter or Send.
- Commands that affect everyone (exit, clearchalk, clearoutside, reloadplugins, ban, say) are red and need a second
  click.

## 1.16.2
- The command list is more compact: a smaller font, at most a few rows tall (less near the bottom of the screen) with
  a scrollbar, and every command is a button you can click to type it in chat.

## 1.16.1
- New **?** button left of the title (next to the admin shield for admins): a list of every command you can use on
  the server, with what it does. Click a command to have it typed in chat for you.
- It asks the server with !help in the background and shows the answer in the list instead of in chat, so it works
  without any server update.

## 1.15.0
- New **Chalk** button: a menu for your chalk saves. Pick a canvas (it starts on the nearest one), type a name and
  **Save**, or **Load**, **Share** or **Delete** any of your saves. Loading, deleting and saving over a save ask for a
  second click. When someone shares a save with you, **Accept** and **Decline** show up in the menu.
- Admins get an **All players** list in the Chalk menu: everyone who has saves, online or not. Click a name to see
  their drawings and load or delete them.
- Needs the updated Chalk Saves plugin on the server.

## 1.14.3
- New description: the player panel for Ether's Wolf Park.

## 1.14.2
- The mod has its own GitHub repository now: https://github.com/faytleingod499/WolfparkHUD
- Released under the MIT License: you're free to copy, change and share your own versions.

## 1.14.1
- The description now notes that this mod was created with the assistance of AI.

## 1.14.0
- Admins get a shield button left of the title. It opens a list of everyone on the server (except the host)
  under the panel, with **Kick** and **Ban** beside each name. Ban asks for a second click. Uses the
  server's own kick and ban commands.

## 1.13.1
- First Thunderstore release.
